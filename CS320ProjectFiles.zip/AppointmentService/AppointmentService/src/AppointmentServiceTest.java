import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

	
	//Tests for adding appointments
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("1", new Date(System.currentTimeMillis() + 100000), "Test");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("1"));
    }

    @Test
    public void testAddDuplicateId() {
        AppointmentService service = new AppointmentService();
        Appointment appt1 = new Appointment("1", new Date(System.currentTimeMillis() + 100000), "Test1");
        Appointment appt2 = new Appointment("1", new Date(System.currentTimeMillis() + 200000), "Test2");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }
    
    //Tests deleting appointments

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("1", new Date(System.currentTimeMillis() + 100000), "Test");
        service.addAppointment(appt);
        service.deleteAppointment("1");
        assertNull(service.getAppointment("1"));
    }
}