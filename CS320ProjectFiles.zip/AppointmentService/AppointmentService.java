import java.util.HashMap;
import java.util.Map;

// store and add appointments
public class AppointmentService {
    private Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Duplicate appointment ID");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    //remove appointments
    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}