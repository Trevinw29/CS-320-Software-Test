import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService service;

    
  // Set up a new Tasks without others
    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        assertEquals(task, service.getTask("1"));
    }

    // Ensures unique IDs
    @Test
    public void testAddDuplicateTask() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task);
        });
    }
    
    //Removing tasks, updating name and description

    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        service.updateTaskName("1", "Updated Name");
        assertEquals("Updated Name", service.getTask("1").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        service.updateTaskDescription("1", "New Description");
        assertEquals("New Description", service.getTask("1").getDescription());
    }
}