import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

//Tests our application 

public class ContactServiceTest {
    private ContactService service;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
        contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    //Tests individual functions

    @Test
    public void testAddContactSuccess() {
        Contact newContact = new Contact("002", "Jane", "Smith", "0987654321", "456 Side St");
        service.addContact(newContact);
        assertEquals("Jane", service.getContact("002").getFirstName());
    }

    @Test
    public void testAddContactWithDuplicateIdFails() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    public void testDeleteContactSuccess() {
        service.deleteContact("001");
        assertThrows(IllegalArgumentException.class, () -> service.getContact("001"));
    }

    @Test
    public void testUpdateFirstName() {
        service.updateFirstName("001", "Jack");
        assertEquals("Jack", service.getContact("001").getFirstName());
    }

    @Test
    public void testUpdatePhoneInvalid() {
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("001", "123"));
    }
}