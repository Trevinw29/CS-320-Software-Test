import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    //Tests our function for contact creation
    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("John", contact.getFirstName());
    }

    @Test
    public void testInvalidContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testPhoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "12345", "123 Main St");
        });
    }

    //Tests our corresponding function 

    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "1234567890", "1234567890123456789012345678901");
        });
    }

    @Test
    public void testSetFirstNameValid() {
        Contact contact = new Contact("001", "Jane", "Smith", "1234567890", "Street");
        contact.setFirstName("Janet");
        assertEquals("Janet", contact.getFirstName());
    }

    @Test
    public void testSetFirstNameTooLong() {
        Contact contact = new Contact("001", "Jane", "Smith", "1234567890", "Street");
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("12345678901"));
    }
}